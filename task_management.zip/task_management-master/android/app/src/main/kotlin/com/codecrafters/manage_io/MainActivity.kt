package com.codecrafters.manage_io

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
